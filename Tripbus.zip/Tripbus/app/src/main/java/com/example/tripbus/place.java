package com.example.tripbus;
import java.util.List;

public class place {
    List<placeInfo> pinfo; //변수명 response->pinfo로 변경 부탁 헷갈려요ㅠㅠ

    public List<placeInfo> getInfo() {
        return pinfo;
    }


}
