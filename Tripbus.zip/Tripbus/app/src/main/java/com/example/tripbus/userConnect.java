package com.example.tripbus;

public class userConnect {
    Boolean success;

    public Boolean getSuccess() { return success; }
}
