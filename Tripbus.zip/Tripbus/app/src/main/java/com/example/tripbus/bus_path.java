package com.example.tripbus;

import android.app.Activity;

public class bus_path extends Activity {
}
