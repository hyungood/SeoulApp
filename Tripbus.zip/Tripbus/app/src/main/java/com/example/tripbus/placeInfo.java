package com.example.tripbus;

public class placeInfo { //3개만 보내주시고 배열로 묶지 말고 풀어주세요~~
    String tour_name;
    String tour_address;
    String tour_img;

    public String getTour_name() {
        return tour_name;
    }

    public String getTour_address() {
        return tour_address;
    }

    public String getTour_img() {
        return tour_img;
    }
}
